var date = new Date();
console.log('date.getFullYear() '+date.getFullYear());
console.log('date.getMonth() '+date.getMonth());
console.log('date.getDate() '+date.getDate());
console.log('date.getHours() '+date.getHours());
console.log('date.getMinutes() '+date.getMinutes());